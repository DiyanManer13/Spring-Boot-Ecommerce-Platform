package service;

import com.ecommerce.project.model.Category;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;


public interface CategoryService {
    List<Category> getAllCategories();
    void createCategory(Category category);

}
